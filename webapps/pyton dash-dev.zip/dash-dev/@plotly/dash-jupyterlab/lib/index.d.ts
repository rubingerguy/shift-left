import { JupyterFrontEndPlugin } from '@jupyterlab/application';
import '../style/index.css';
/**
 * Initialization data for the jupyterlab-dash extension.
 */
declare const extension: JupyterFrontEndPlugin<void>;
export default extension;
