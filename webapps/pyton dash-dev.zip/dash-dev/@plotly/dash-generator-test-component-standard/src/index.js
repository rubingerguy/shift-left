import MyStandardComponent from './components/MyStandardComponent';

export {
    MyStandardComponent,
};
