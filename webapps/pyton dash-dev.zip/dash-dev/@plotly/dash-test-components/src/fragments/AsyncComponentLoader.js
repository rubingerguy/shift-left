export default () => import(/* webpackChunkName: "test-async" */ './AsyncComponent');
