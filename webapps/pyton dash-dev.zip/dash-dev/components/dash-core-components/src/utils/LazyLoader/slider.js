export default () => import(/* webpackChunkName: "slider" */ '../../fragments/Slider.react');

