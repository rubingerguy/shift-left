export type ResultFn<TArgs extends any[], TEntry> = (...args: TArgs) => TEntry;
